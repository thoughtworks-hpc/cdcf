/*
 * Copyright (c) 2019-2020 ThoughtWorks Inc.
 */
#ifndef ACTOR_SYSTEM_INCLUDE_ACTOR_SYSTEM_CONFIG_H_
#define ACTOR_SYSTEM_INCLUDE_ACTOR_SYSTEM_CONFIG_H_
#include <cdcf_config.h>

#include <cstdint>
#include <string>

namespace actor_system {
class Config : public CDCFConfig {
 public:
  uint16_t port_ = 4750;

  Config() {
    opt_group{custom_options_, "global"}.add(port_, "actor_system_port,a",
                                             "set port for actor_system");
  }
};
}  // namespace actor_system
#endif  // ACTOR_SYSTEM_INCLUDE_ACTOR_SYSTEM_CONFIG_H_
