/*
 * Copyright (c) 2019 ThoughtWorks Inc.
 */

#ifndef CONFIG_MANAGER_INCLUDE_CONFIG_MANAGER_TEST_H_
#define CONFIG_MANAGER_INCLUDE_CONFIG_MANAGER_TEST_H_

#include <string>

char INI_FILE_PARAMETER[] =
    "--config-file="
    "/Users/yuecheng.pei/.conan/data/cdcf/1.0/x4/stable/build/ba37b9c0a1842f6929ee6ddcac04324e84ef12ae/cdcf/config_manager/test_source/test.ini";
#endif  // CONFIG_MANAGER_INCLUDE_CONFIG_MANAGER_TEST_H_
